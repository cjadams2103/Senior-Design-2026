#define SECRET_SSID "SSID"      // replace MySSID with your Wifi network name
#define SECRET_PASS "PASSWORD"  // replace MyPassword with your WiFi password
#define SECRET_CH_ID 12345678            // replace 0000000 with your channel number
#define SECRET_WRITE_APIKEY "ABCDEFGHIJ1234567"  // replace XYZ with your channel write API Key
